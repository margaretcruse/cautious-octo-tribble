//Margaret Cruse CRCP 3330

//Class:HelloWorldMidiMain
//Description:main file, do the thing

import processing.core.*;

import java.util.*;

//importing the JMusic stuff
import jm.music.data.*;
import jm.JMC;
import jm.util.*;
import jm.midi.*;

import java.io.UnsupportedEncodingException;
import java.net.*;

//import javax.sound.midi.*;

//make sure this class name matches your file name, if not fix.
public class HelloWorldMidiMain extends PApplet {

	MelodyPlayer player; // play a midi sequence
	MidiFileToNotes midiNotes; // read a midi file
	MarkovGenerator<Float> pitches = new MarkovGenerator();
	ProbabilityGenerator<Double> rhythms = new ProbabilityGenerator();
	ProbabilityGenerator probDistGen = new ProbabilityGenerator();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main("HelloWorldMidiMain"); // change this to match above class & file name

	}

	// setting the window size to 300x300
	public void settings() {
		size(300, 300);

	}

	// doing all the setup stuff
	public void setup() {
		fill(120, 50, 240);

		// returns a url
		String filePath = getPath("mid/MaryHadALittleLamb.mid");
		// playMidiFile(filePath);

		midiNotes = new MidiFileToNotes(filePath); // creates a new MidiFileToNotes -- reminder -- ALL objects in Java
													// must
													// be created with "new". Note how every object is a pointer or
													// reference. Every. single. one.

//		// which line to read in --> this object only reads one line (or ie, voice or ie, one instrument)'s worth of data from the file
		midiNotes.setWhichLine(0);

		rhythms.train(midiNotes.getRhythmArray());
		pitches.train(midiNotes.getPitchArray());
		pitches.trainMarkov(midiNotes.getPitchArray());

		player = new MelodyPlayer(this, 100.0f);

		player.setup();
		player.setMelody(midiNotes.getPitchArray());
		player.setRhythm(midiNotes.getRhythmArray());

	}

	public void draw() {
		// player.play(); //play each note in the sequence -- the player will determine
		// whether is time for a note onset
		display();
	}

	// this finds the absolute path of a file
	String getPath(String path) {

		String filePath = "";
		try {
			filePath = URLDecoder.decode(getClass().getResource(path).getPath(), "UTF-8");

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return filePath;
	}

	// this function is not currently called. you may call this from setup() if you
	// want to test
	// this just plays the midi file -- all of it via your software synth. You will
	// not use this function in upcoming projects
	// but it could be a good debug tool.
	void playMidiFile(String filename) {
		Score theScore = new Score("Temporary score");
		Read.midi(theScore, filename);
		Play.midi(theScore);
	}

	// this starts & restarts the melody.
	public void keyPressed() {
		if (key == ' ') {
			player.reset();
			println("Melody started!");
		}
		if (key == '1') {
			unitTest1(pitches);// unit test 1 project 1
			unitTest1(rhythms);
		}
		if (key == '2') {
			unitTest2();// unit test 2 project 1
		}
		if (key == '3') {
			// unit test 3 project 1
			unitTest3(pitches, midiNotes.getPitchArray());
			unitTest3(rhythms, midiNotes.getRhythmArray());
		}
		if (key == '4') {
			for (int i = 0; i < pitches.transitionTable.size(); i++) {

				println(pitches.transitionTable.get(i));// unit test 1 project 2

			}
		}
		if (key == '5') {
			println(pitches.generateMarkov(20));
		}
		if (key == '6') {
			treeTest();
		}
		if (key == '7') {
			treeElim();
			treeElim15();
		}
	}

	public void display() { // function to display gui text
		textSize(12);
		text("press '1' to run unit test 1", 10, 20);
		text("press '2' to run unit test 2", 10, 40);
		text("press '4' to run unit test 1 from project 2", 10, 80);
		text("press '5' to run unit test 3 from project 2", 10, 100);
		text("press '6' for project 5 part 1 unit tests", 10, 120);
		text("press '7' for project 5 part 2 unit tests", 10, 140);
	}

	public void unitTest1(ProbabilityGenerator tokens) {
		println();
		println("-----Probability Distribution-----");
		for (int i = 0; i < tokens.prob.size(); i++) {

			println("Token:" + tokens.alphabet.get(i) + "| Probability:" + tokens.prob.get(i));
		}

	}

	public void unitTest2() {
		player.setMelody(pitches.generate(20, pitches.prob));
		player.setRhythm(rhythms.generate(20, rhythms.prob));
	}

	public void unitTest3(ProbabilityGenerator melodyGen, ArrayList song) {
		melodyGen.train(song);

		for (int j = 0; j < 10000; j++) {
			ArrayList newSong = melodyGen.generate(20, melodyGen.prob);
			probDistGen.train(newSong);
		}
		unitTest1(probDistGen);
	}

	public void treeTest() {
		Tree tree = new Tree();

		String[] myList = { "a", "b", "r", "a", "c", "a", "d", "a", "b", "r", "a" };
		ArrayList<String> testList = new ArrayList(Arrays.asList(myList));
		tree.trainPST(testList, false);
		println("--------------------");
		println("abracadabra: PST L=3");
		println("--------------------");
		tree.print();
		
		Tree t2Tree = new Tree();

		String[] t2 = { "a", "c", "a", "d", "a", "a", "c", "b", "d", "a" };
		ArrayList<String> t2List = new ArrayList(Arrays.asList(t2));
		t2Tree.trainPST(t2List, false);
		println("--------------------");
		println("acadaacbda: PST L=3");
		println("--------------------");
		t2Tree.print();
		
		Tree t3Tree = new Tree();

		String[] t3 = { "a", "b", "c", "c", "c", "d", "a", "a", "d", "c", "d", "a", "a", "d", "c", "a", "d", "a", "d" };
		ArrayList<String> t3List = new ArrayList(Arrays.asList(myList));
		t3Tree.trainPST(t3List, false);
		println("--------------------");
		println("acadaacbda: PST L=3");
		println("--------------------");
		t3Tree.print();
		
		Tree mTree = new Tree();

		mTree.trainPST(midiNotes.getPitchArray(), false);
		println("--------------------");
		println("Mary Had a Little Lamb: PST L=3");
		println("--------------------");
		mTree.print();
	}

	public void treeElim() {
		Tree tree = new Tree(0.1);

		String[] myList = { "a", "b", "r", "a", "c", "a", "d", "a", "b", "r", "a" };
		ArrayList<String> testList = new ArrayList(Arrays.asList(myList));
		tree.trainPST(testList, true);
		println("--------------------");
		println("abracadabra: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		tree.print();
		
		Tree t2Tree = new Tree(0.1);

		String[] t2 = { "a", "c", "a", "d", "a", "a", "c", "b", "d", "a" };
		ArrayList<String> t2List = new ArrayList(Arrays.asList(t2));
		t2Tree.trainPST(t2List, true);
		println("--------------------");
		println("acadaacbda: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		t2Tree.print();
		
		Tree t3Tree = new Tree(0.1);

		String[] t3 = { "a", "b", "c", "c", "c", "d", "a", "a", "d", "c", "d", "a", "a", "d", "c", "a", "d", "a", "d" };
		ArrayList<String> t3List = new ArrayList(Arrays.asList(myList));
		t3Tree.trainPST(t3List, true);
		println("--------------------");
		println("acadaacbda: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		t3Tree.print();
		
		Tree mTree = new Tree(0.1);

		mTree.trainPST(midiNotes.getPitchArray(), true);
		println("--------------------");
		println("Mary Had a Little Lamb: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		mTree.print();
	}
	public void treeElim15() {
		Tree tree = new Tree(0.15);

		String[] myList = { "a", "b", "r", "a", "c", "a", "d", "a", "b", "r", "a" };
		ArrayList<String> testList = new ArrayList(Arrays.asList(myList));
		tree.trainPST(testList, true);
		println("--------------------");
		println("abracadabra: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		tree.print();
		
		Tree t2Tree = new Tree(0.15);

		String[] t2 = { "a", "c", "a", "d", "a", "a", "c", "b", "d", "a" };
		ArrayList<String> t2List = new ArrayList(Arrays.asList(t2));
		t2Tree.trainPST(t2List, true);
		println("--------------------");
		println("acadaacbda: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		t2Tree.print();
		
		Tree t3Tree = new Tree(0.15);

		String[] t3 = { "a", "b", "c", "c", "c", "d", "a", "a", "d", "c", "d", "a", "a", "d", "c", "a", "d", "a", "d" };
		ArrayList<String> t3List = new ArrayList(Arrays.asList(myList));
		t3Tree.trainPST(t3List, true);
		println("--------------------");
		println("acadaacbda: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		t3Tree.print();
		
		Tree mTree = new Tree(0.15);

		mTree.trainPST(midiNotes.getPitchArray(), true);
		println("--------------------");
		println("Mary Had a Little Lamb: PST L=3"+ " Pmin = "+tree.pMin);
		println("--------------------");
		mTree.print();
		
	}

}
