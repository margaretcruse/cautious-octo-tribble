//Margaret Cruse CRCP3330

//Class: ProbabilityGenerator
//Description: train and generate new notes based on input and probability
//

import java.util.ArrayList;

public class ProbabilityGenerator<T> {
	
	
	
	ArrayList<T> alphabet = new ArrayList<T>();
	ArrayList<T> generNotes = new ArrayList<T>();
	ArrayList<Float> counts = new ArrayList<Float>();
	ArrayList<Float> prob = new ArrayList<Float>();
	ArrayList<Float> probDist = new ArrayList<Float>();
	
	float total;
	int index;
	
	


	public void train(ArrayList newtokens) {
		
		for(int i= 0; i < newtokens.size(); i++){
			if(alphabet.contains(newtokens.get(i))==false) {
					alphabet.add((T) newtokens.get(i)); //add token to alphabet of unique tokens
					counts.add((float)1.0); //start the count for token
					
			}
			else {
					int alpha = alphabet.indexOf(newtokens.get(i));
					float add = counts.get(alpha) + 1;//add one to the token's count
					counts.set(alpha, add); //update counts when token is found
					
			}
		}
		 total+= newtokens.size();
		for(int j=0; j < counts.size(); j++) {
			
			float probability = ( (float) counts.get(j))/total;//find the probability of each token
			prob.add(j, probability);//put probability to list
		}
		
	}
		
		
	
	public ArrayList<T> generate(int n, ArrayList<Float> prob) {
		generNotes.clear();//clears generNotes to not pollute data 
		
		
		probDist.add(prob.get(0));
		for(int i=1; i<prob.size();i++) {
			float add = probDist.get(i-1)+prob.get(i);//create distribution 
			probDist.add(add);
		}
		
		
		
		for(int j=0; j <n; j++) {
			float randIndex = (float)	Math.random();//random decimal to generate from distribution
			int k=0;
			while(k<probDist.size()) {
				if (randIndex > probDist.get(k)) {
					k++; //count through probdist until == randIndex
				}
				else {
					generNotes.add(alphabet.get(k)); //add corresponding note to new list
					break;
				}
			}
		}
		
		return generNotes;
		
	} 
	
	
	
}



