//Margaret Cruse CRCP3330

//Class: MarkovGenerator
//Description: train and generate new notes based on input and markov algorithm


import java.util.ArrayList;



public class MarkovGenerator<T> extends ProbabilityGenerator{

	ArrayList<ArrayList<Float>> transitionTable = new ArrayList<ArrayList<Float>>();
	ProbabilityGenerator trainer = new ProbabilityGenerator();
	int tokenIndex;
	//ArrayList<T> alphabet = new ArrayList<T>();
	
	
	

	
	public void trainMarkov(ArrayList input) {
		int lastIndex=-1;
		int index;
		
		
		//create empty transition table
		trainer.train(input);//train input through probability generator to get alphabet		
		for(int i= 0; i<trainer.alphabet.size(); i++) {
			ArrayList<Float> myRow= new ArrayList();	
			for(int j = 0; j<trainer.alphabet.size();j++) {
				
			myRow.add((float) 0.0);
			}
			transitionTable.add(myRow);
		}
		for(int k=0; k<input.size(); k++) {
			if(k==0) {
			lastIndex=trainer.alphabet.indexOf(input.get(k));
			}
			else {
			index= trainer.alphabet.indexOf(input.get(k));
			ArrayList<Float> row = transitionTable.get(lastIndex);
			float add=row.get(index);
			add++;
			row.set(index, add);
			transitionTable.set(lastIndex, row);
			lastIndex=index;
			}
		}
		for(int i=0; i<trainer.alphabet.size();i++) {
			ArrayList<Float> row = transitionTable.get(i);
			for(int j=0; j<trainer.alphabet.size();j++) {
				
				float value = (row.get(j)/(float)trainer.counts.get(i));
				row.set(j, value);
			}
			transitionTable.set(i, row);
		}
	}
	
	public ArrayList<T> generateMarkov(int n){
		ArrayList<T> token = new ArrayList<T>();
		ArrayList<T> output = new ArrayList<T>();
		for(int i=0; i<n; i++) {
			if(i==0) {
				token = trainer.generate(1, trainer.prob); //random initial token
			}
			else {
			T initToken = token.get(0);//store init token to find in transition table
			output.add(initToken);

			int index = trainer.alphabet.indexOf(initToken); //get index of init token in alphabet
			ArrayList<Float> row = transitionTable.get(index); //get prob row of token
			
			token = trainer.generate(1, row); //generate off transition table tow
			}
		}
		
		
		
		return output;
	}
		
		 
		
	
}
	

