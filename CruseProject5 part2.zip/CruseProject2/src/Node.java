
//Margaret Cruse CRCP3330

import java.util.ArrayList;

public class Node<T> {
	ArrayList<T> tokenSequence = new ArrayList<T>();
	ArrayList<Node> children = new ArrayList<Node>();
	int count = 1;

	public Node(ArrayList<T> token) {
		this.tokenSequence = token;
	}

	public Node() {
		ArrayList<T> tokenSequence = new ArrayList<T>();
	}

	boolean addNode(Node<T> node) {
		boolean found = false;
		int i = 0;

		if (tokenSequence.equals(node.tokenSequence)) {
			found = true;
			count++;
		}

		else if (amIASuffix(node) || (tokenSequence.size() == 0)) {

			while (!found && i < children.size()) {
				// try to add
				found = children.get(i).addNode(node);
				i++;
			}
			// if children didn't add
			if (!found) {
				children.add(node);
				found = true;
			}

		}
		return found;
	}

	boolean amIASuffix(Node<T> node) {
		boolean Gilbert = false;
		int toIndex = node.tokenSequence.size();
		int fromIndex = node.tokenSequence.size() - tokenSequence.size();

		if (tokenSequence.equals(node.tokenSequence.subList(fromIndex, toIndex))) {
			Gilbert = true;
		}

		return Gilbert;
	}

	boolean pMinElimination(int totalTokens, double pMin) {
		boolean shouldRemove = false;
		float num = (count / (float) (totalTokens - (tokenSequence.size() - 1)));

		if (num <= pMin && tokenSequence.size() != 0) {
			shouldRemove = true;
		} else {
			for (int i = children.size() - 1; i > 0; i--) {
				if (children.get(i).pMinElimination(totalTokens, pMin)) {
					children.remove(children.get(i));
					
				}
			}
			shouldRemove = false;
		}
		return shouldRemove;
	}

	void print() {
		System.out.println(tokenSequence);
		for (int i = 0; i < children.size(); i++) {
			children.get(i).print(1);
		}
	}

	void print(int numSpacesBefore) {

		for (int i = 1; i <= numSpacesBefore; i++) {
			System.out.print(" ");
		}
		System.out.print("-->");
		System.out.println(tokenSequence);

		for (int j = 0; j < children.size(); j++) {
			children.get(j).print(numSpacesBefore + 1);
		}
	}

}
