//Margaret Cruse CRCP3330

//Class: MarkovGenerator
//Description: train and generate new notes based on input and markov algorithm

import java.util.ArrayList;

public class Tree<T> extends ProbabilityGenerator<T> {

	int L = 3;
	double pMin;
	int totalInputTokens;
	
	Tree(double pMin){
		this.pMin = pMin;
	}
	Tree(){
		
	}

	ArrayList<T> compare = new ArrayList<T>();
	Node<T> root = new Node<T>();

	void trainPST(ArrayList<T> input, boolean pLim) {

		for (int i = 1; i <= L; i++) {
			for (int k = 0; k <= input.size() - i; k++) {
				ArrayList<T> curSequence = new ArrayList<T>();
				for (int j = 0; j < i; j++) {
					curSequence.add(input.get(k + j));

				}

				Node<T> node = new Node<T>(curSequence);

				root.addNode(node);

			}
		}
		totalInputTokens = input.size();
		if (pLim == true) {
			root.pMinElimination(totalInputTokens, pMin);

		}
	}

	void print() {
		root.print(1);
	}

}
